package com.cursojavabasico.aula10;

public class Variaveis {

    public static void main(String[] args) {

        //convencao Java
        int idade = 20;
        String nome = "Ricardo";
        String nomeDoMeuCachorro = "Lulinha";
        String ano2014 = "2014";


        //aceito, mas nao utilizada
        int _idade;
        int $idade;


        //nao e convencao Java
        String nome_do_meu_cachorro;
        String NomeDoMeuCachorro;
        String NomeDoMeucachorro;

        idade = 25;

        System.out.println("Idade = " + idade);
        System.out.println("Nome = " + nome);

    }
}
