package com.cursojavabasico.aula15;

import org.w3c.dom.ls.LSOutput;

import java.util.Scanner;

public class Exercicio02 {


    //faca um programa que peca um valor e mostre na tela se vo valor é positivo ou negativo

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);


        System.out.println("Entre com um numero: ");
        int num = scan.nextInt();

        if (num >= 0){
            System.out.println("O  numero informado é positivo:");
        } else {
            System.out.println("O  numero informado é negativo:");

        }

    }
}
