package com.cursojavabasico.aula15;

import java.util.Scanner;

public class Exercicio01 {

    //faca um programa que peca dois numeros e imprima o maior deles.

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in );

        System.out.println("Entre com o primeiro numero");
        int num1 = scan.nextInt();

        System.out.println("Entre com o segundo numero");
        int num2 = scan.nextInt();

        if (num1 > num2){
            System.out.println("O num1 é maior: " + num1);
        } else {
            System.out.println("O num2 é maior: " + num2);

        }
    }
}
