package com.cursojavabasico.aula15;

import java.util.Scanner;

public class ExercicioSwitchCase {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Selecione um numero de 1 a 5:");
        int num = scan.nextInt();

        switch(num){
            case 1:
                System.out.println("Voce escolheu 1.");
                break; // encerrar o ciclo, ele para na linha de comando, se nao tiver essa linha break ele vai executar a proxima instrucao
            case 2:
                System.out.println("Voce escolheu 2.");
                break;
            case 3:
                System.out.println("Voce escolheu 3.");
                break;
            case 4:
                System.out.println("Voce escolheu 4.");
                break;
            case 5:
                System.out.println("Voce escolheu 5.");
                break;
            default:
                System.out.println("Esse numero nao existe ");
        }
    }
}
