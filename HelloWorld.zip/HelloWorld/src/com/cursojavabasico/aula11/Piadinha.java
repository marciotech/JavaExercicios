package com.cursojavabasico.aula11;

public class Piadinha {

    public static void main(String[] args) {

         int ct31 = 031; // verificar pq quando add o numero '0' dar erro

        int Dec25 = 25;

        System.out.println(ct31 == Dec25);


    }
}
