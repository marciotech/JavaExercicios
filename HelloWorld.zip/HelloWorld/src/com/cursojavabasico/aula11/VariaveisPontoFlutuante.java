package com.cursojavabasico.aula11;

public class VariaveisPontoFlutuante {

    public static void main(String[] args) {

        double valorPassagem = 2.90;

        float valorTomate = 3.95f;


        System.out.println("Valor da passagem = " + valorPassagem);

        System.out.println("Valor do tomate = " + valorTomate);
    }
}
