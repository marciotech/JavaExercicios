package com.cursojavabasico.aula11;

public class SequenciaEscape {

    public static void main(String[] args) {

        //"Hello, World!"
        System.out.println("\"Hello, World!\"\n\r");
        //1\4
        System.out.println("1\\4");

    }
}
