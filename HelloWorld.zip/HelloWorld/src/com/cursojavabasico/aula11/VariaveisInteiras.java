package com.cursojavabasico.aula11;

public class VariaveisInteiras {

    public static void main(String[] args) {

        byte idade01 =  20;

        short idade02 = 21;

        int idade03 =   22;

        long idade04 = 23;

        System.out.println("Valor variavel idade01 = "+ idade01);
        System.out.println("Valor variavel idade02 = "+ idade02);
        System.out.println("Valor variavel idade03 = "+ idade03);
        System.out.println("Valor variavel idade04 = "+ idade04);


    }

}
