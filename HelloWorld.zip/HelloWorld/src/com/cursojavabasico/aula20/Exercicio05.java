package com.cursojavabasico.aula20;

public class Exercicio05 {

    public static void main(String[] args) {


    }
}
