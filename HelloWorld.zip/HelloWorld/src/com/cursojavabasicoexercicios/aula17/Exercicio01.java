package com.cursojavabasicoexercicios.aula17;

import javax.sound.midi.Soundbank;
import java.util.Scanner;

public class Exercicio01 {

    //faca um programa que peca uma nota, entre zero e dez, mostre uma mensagem caso o valor seja invalido e continue pedindo até que o usuario informe um valor válido

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        boolean notaValida = false;

        do {

            System.out.println("Entre com uma nota");

            double nota = scan.nextDouble();

            if (nota >= 10 && nota <= 10) {
                notaValida = true;
                System.out.println("Voce digitou: " + nota);
            } else {
                System.out.println("Nota inválida, digite novamente. ");
            }
        } while (!notaValida);

    }
}
