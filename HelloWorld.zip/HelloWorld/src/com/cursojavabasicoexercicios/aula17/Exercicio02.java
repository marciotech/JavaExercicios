package com.cursojavabasicoexercicios.aula17;

import java.util.Scanner;

public class Exercicio02 {


    // faca um programa que leia o nome de um usuario e a senha e nao aceite a senha igual ao nome do usuario, mostrando uma mensagem de erro e voltando a pedir as informacoes.

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        boolean infoValidas = false;

        do {

            System.out.println("Entre com o nome do usuario:");
            String nomeUser = scan.next();

            System.out.println("Entre com a senha:");
            String senha = scan.next();

            if (nomeUser.equalsIgnoreCase(senha)){
               // infoValidas = false;
                System.out.println("Senha igual a usuario, digite novamente");
            } else {
                infoValidas = true;
                System.out.println("Senha e usuário válidos.");
            }


        } while (!infoValidas);


    }

}
