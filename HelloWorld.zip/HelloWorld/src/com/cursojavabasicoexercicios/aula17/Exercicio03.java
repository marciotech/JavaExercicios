package com.cursojavabasicoexercicios.aula17;

import java.util.Scanner;

public class Exercicio03 {

    //faca um programa que leia e valide as seguintes informacos;
    //a-Nome:maiorque3caracteres
    //b-Idade: entre 0 e 150;
    //c-Salário:maior entre 0 e 150;
    //d-Sexo: "f"ou "m";
    // e - Estado Civil: 's', 'c'' 'v'' 'd',


    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
    }
}
