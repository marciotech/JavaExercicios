package com.example.aula6;



    class HelloWorld {

        public static void main(String[] args) {

            System.out.println("Voce digitou " +args);
        }
    }

