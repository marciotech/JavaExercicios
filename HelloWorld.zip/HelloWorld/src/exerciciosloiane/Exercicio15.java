package exerciciosloiane;

public class Exercicio15 {

    public static void main(String[] args) {

        String cor = "Verde";

        if (cor.equals("Verde")) {
            System.out.println("Andar");
            } else {
                System.out.println("Parar e aguardar");
            }

        }
    }
