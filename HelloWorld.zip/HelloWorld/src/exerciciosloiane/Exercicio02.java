package exerciciosloiane;

import java.util.Scanner;

public class Exercicio02 {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Entre com um número inteiro: + numero ");
        int numero = scan.nextInt();
        System.out.println("O número informado foi: ");


    }
}
